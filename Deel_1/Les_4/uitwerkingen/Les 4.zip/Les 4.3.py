#Opdracht 3
var1 = "Hallo! "
var2 = "Ranya "
var3 = "Ik leer programmeren! "
#Opdracht 3
var4 = "Hallo! "
var5 = "252 "
var6 = "Ik leer programmeren! "

print(var1+var2+var3)
print(var4+var5+var6)
# in dit programma gebruik je variable en strings
#Als je de naam veranderd van var2 werkt het nogsteeds het zelfde!
