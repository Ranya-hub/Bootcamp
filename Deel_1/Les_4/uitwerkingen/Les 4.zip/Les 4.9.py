#Opdracht 9
student = 20
prize = 1200

print(prize * student)

appel = 3.40

druiven = 2.45

bananen = 1.95
btw = 9
total = druiven + appel + bananen
total = total / 100 * 109
print(total)