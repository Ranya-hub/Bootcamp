#Opdracht 6
print(((2*3)/4 + (5 - 6/7)) * 8)
# bij deze som misten er een paar haakjes om te sluiten. vandaar dat het niet werkte

print(((12 * 13) / 14) + ((15 - 16) / 17 *18))
#Ook hier het zelfde verhaal. hier miste ook een paar haakjes