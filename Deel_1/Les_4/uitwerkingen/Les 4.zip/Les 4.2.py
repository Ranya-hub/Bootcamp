#Opdracht 2
print( 5*2 -3+4/2 )
print( 5*2 - 3+4 / 2 )
# ja je krijgt het zelfde antwoord