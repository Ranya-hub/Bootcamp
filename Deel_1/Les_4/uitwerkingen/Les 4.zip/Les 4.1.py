#Opdracht 1
print( 15+4 )
print( 15-4 )
print( 15*4 )
print( 15/4 )
print( 15//4 )
print( 15**4 )
print( 15%4 )
#de // zorgt er voor dat de som word gedeeld maar dat het antwoord ook terug komt.
# de ** betekend tot de macht van.
# de % betekend de restwaarde van de som. in dit geval is de restwaarde 3.