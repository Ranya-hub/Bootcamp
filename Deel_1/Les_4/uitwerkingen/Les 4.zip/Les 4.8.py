#Opdracht 8
var4 = 625
var5 = 13

aantal = var4 // var5
over = var4 % var5
print(f"13 past zoveel keer in 625  {aantal}" )
print(f"Er blijft zoveel over {over}")
#Wat we doen is we delen het hele getal, daarvoor gebruik je //
#De % teken zorgt er voor dat het getal over blijft apart blijft.
# Vervolgens print je uit de variable en heb je het antwoord.