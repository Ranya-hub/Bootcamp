#Opdracht 4
#Als je bij var2 252 zet, werkt het niet want het is geen string, het moet een string zijn om het te laten werken.
