#Opdracht 10
Secondes_minuut = 60
Minuten_Per_uur = 60
Uren_per_dag = 24
dagen_perweek = 7
dagen_per_jaar = 365

Uren_per_dag * Minuten_Per_uur * Secondes_minuut
Secondes_minuut * dagen_perweek
Secondes_minuut* dagen_per_jaar

