#Opdracht 7
print( (431 / 100) * 100 )
#Het laat hier niets zien