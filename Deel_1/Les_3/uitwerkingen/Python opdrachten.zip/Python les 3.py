woord1 = input("Wat voor soort dag is het? ")
woord2 = input("Wat is de naam van de hoofd persoon? ")
woord3 = input("In welke stad liep je character? ")
woord4 = input("Naar wat was je character opzoek? ")
woord5 = input("Waar kwam de character?")
woord6 = input("Wat deden de groep mensen? ")
woord7 = input("Wat verkocht de man? ")

print(f"Het was een {woord1} dag in {woord3}. {woord2} liep door de straten, op zoek naar een {woord4}. Plotseling zag je een man die een {woord7} verkocht. {woord2} besloot om het te kopen en liep verder. Toen {woord2} bij een {woord5} kwam, zag hij/zij een groep mensen die {woord6}. {woord2} besloot om mee te doen en had de tijd van zijn/haar leven.")

